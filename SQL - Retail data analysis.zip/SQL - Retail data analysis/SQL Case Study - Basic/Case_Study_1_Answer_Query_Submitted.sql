select * from customer;
select * from Transactions;
select * from prod_cat_info;

/*************************************************************************************************************************************/
/*************************************************************************************************************************************/

--DATA PREPARATION AND UNDERSTANDING : 


--Q1. What is the total number of rows in each of the 3 tables in the database?
SELECT COUNT(*) AS TOTAL_NO_CUSTOMER FROM CUSTOMER  
SELECT COUNT(*) AS TOTAL_NO_TRANSACTIONS FROM TRANSACTIONS  
SELECT COUNT(*) AS TOTAL_NO_PROD_CAT_INFO FROM PROD_CAT_INFO 



--Q2. What is the total number of transactions that have a return?
SELECT COUNT(TOTAL_AMT) AS RETURN_TRANSACTIONS FROM TRANSACTIONS
WHERE TOTAL_AMT LIKE '-%'



--Q3. As you would have noticed, the dates provided across the datasets are not in a correct format. As first steps, pls 
	--convert the date variables into valid date formats before proceeding ahead.
SELECT CONVERT(DATE, DOB, 105) AS DATES_CUSTOMER FROM CUSTOMER 
SELECT CONVERT(DATE, tran_date, 105) AS DATES_TRANSACTIONS FROM TRANSACTIONS



--Q4. What is the time range of the transaction data available for analysis? 
	--Show the output in number of days, months and years simultaneously
	--in different columns.
SELECT 
DATEDIFF(DAY, MIN(CONVERT(DATE, tran_date, 105)), MAX(CONVERT(DATE, tran_date, 105))) AS No_Of_Days, 
DATEDIFF(MONTH, MIN(CONVERT(DATE, tran_date, 105)), MAX(CONVERT(DATE, tran_date, 105))) AS No_Of_Months,  
DATEDIFF(YEAR, MIN(CONVERT(DATE, tran_date, 105)), MAX(CONVERT(DATE, tran_date, 105))) AS No_Of_Years
FROM 
TRANSACTIONS



--Q5. Which product category does the sub-category �DIY� belong to?
SELECT prod_cat
FROM prod_cat_info
WHERE prod_subcat LIKE 'DIY'



/*************************************************************************************************************************************/
/*************************************************************************************************************************************/

select * from customer;
select * from Transactions;
select * from prod_cat_info;

--DATA ANALYSIS:


--Q1. Which channel is most frequently used for transactions?
SELECT TOP 1 
STORE_TYPE, 
COUNT(TRANSACTION_ID) as Count_Most
FROM 
TRANSACTIONS 
GROUP BY 
STORE_TYPE
ORDER BY 
COUNT(TRANSACTION_ID) DESC



--Q2. What is the count of Male and Female customers in the database?
SELECT 
GENDER, 
COUNT(CUSTOMER_ID) AS Total_Count
FROM 
CUSTOMER
WHERE 
GENDER IN ('M' , 'F')
GROUP BY 
GENDER



--Q3. From which city do we have the maximum number of customers and how many?
SELECT TOP 1
CITY_CODE, COUNT(CUSTOMER_ID) AS CUST_CNT
FROM 
CUSTOMER
GROUP BY 
CITY_CODE
ORDER BY 
CUST_CNT DESC



--Q4. How many sub-categories are there under the Books category?
SELECT 
COUNT(PROD_SUBCAT) AS TOTAL_SUBCAT_CNT
FROM 
prod_cat_info
WHERE 
PROD_CAT = 'BOOKS'
GROUP BY 
PROD_CAT



--Q5. What is the maximum quantity of products ever ordered?
SELECT
MAX(QTY) AS Max_Prod
FROM
TRANSACTIONS



--Q6. What is the net total revenue generated in categories Electronics and Books?
SELECT
SUM(total_amt) as Net_Total_Revenue
FROM 
TRANSACTIONS AS T
INNER JOIN prod_cat_info AS P ON P.prod_cat_code = T.prod_cat_code
WHERE
P.prod_cat IN ('Electronics', 'Books');



--Q7. How many customers have >10 transactions with us, excluding returns?
SELECT
COUNT(CUSTOMER_ID) AS CUSTOMER_COUNT
FROM 
CUSTOMER
WHERE 
CUSTOMER_ID IN 
(SELECT CUST_ID
FROM 
Transactions 
LEFT JOIN CUSTOMER ON CUSTOMER_ID = CUST_ID
WHERE TOTAL_AMT NOT LIKE '-%'
GROUP BY
CUST_ID
HAVING 
COUNT(TRANSACTION_ID) > 10
)



--Q8. What is the combined revenue earned from the �Electronics� & �Clothing� categories, from �Flagship stores�?
SELECT
SUM(total_amt) as Net_Total_Revenue
FROM 
TRANSACTIONS AS T
INNER JOIN prod_cat_info AS P ON P.prod_cat_code = T.prod_cat_code
WHERE
P.prod_cat IN ('Electronics', 'Clothing') AND T.Store_type='Flagship store';



--Q9. What is the total revenue generated from �Male� customers in �Electronics� category? Output should display total revenue by prod sub-cat.
SELECT
PROD_SUBCAT,
SUM(TOTAL_AMT) AS REVENUE
FROM
Transactions AS T
INNER JOIN customer AS C ON T.CUST_ID = C.CUSTOMER_ID
INNER JOIN prod_cat_info AS P ON P.PROD_SUB_CAT_CODE = T.PROD_SUBCAT_CODE AND T.PROD_CAT_CODE = P.PROD_CAT_CODE
WHERE
P.PROD_CAT = 'Electronics' AND C.GENDER = 'M'
GROUP BY
PROD_SUBCAT;



--Q10. What is percentage of sales and returns by product sub category, display only top 5 sub categories in terms of sales?

Select Top 5 prod_subcat,
Round(SUM(TOTAL_AMT)* 100/(SELECT SUM(TOTAL_AMT) FROM Transactions),2) [Sales %],
Round(Sum(Case When Qty < 0 Then Qty Else 0 end),2)* 100/Round(Sum(Case When Qty > 0 Then Qty Else 0 end),2) [asReturn%]
from Transactions as T
INNER JOIN prod_cat_info as P ON T.prod_subcat_code = P.prod_sub_cat_code
group by P.prod_subcat
order by
SUM(TOTAL_AMT) DESC



--Q11. For all customers aged between 25 to 35 years find what is the net total revenue generated by these consumers in last 
     --30 days of transactions from max transaction date available in the data?
SELECT 
CUST_ID,
SUM(TOTAL_AMT) AS NET_TOTAL_REVENUE 
FROM 
Transactions
WHERE 
     CUST_ID IN 
	(SELECT CUSTOMER_ID
	 FROM CUSTOMER
     WHERE DATEDIFF(YEAR,CONVERT(DATE,DOB),GETDATE()) BETWEEN 25 AND 35)
     AND 
	 CONVERT(DATE,TRAN_DATE) 
	 BETWEEN 
	 DATEADD(DAY,-30,(SELECT MAX(CONVERT(DATE,TRAN_DATE)) FROM Transactions)) AND (SELECT MAX(CONVERT(DATE,TRAN_DATE)) FROM Transactions)
GROUP BY CUST_ID


--Q12. Which product category has seen the max value of returns in the last 3 months of transactions?
SELECT TOP 1
P.PROD_CAT,
SUM(TOTAL_AMT) AS TOTAL_RETURNS
FROM
Transactions AS T
INNER JOIN prod_cat_info AS P ON T.PROD_CAT_CODE = P.PROD_CAT_CODE AND 	T.PROD_SUBCAT_CODE = P.PROD_SUB_CAT_CODE
WHERE
    TOTAL_AMT < 0  
	AND
	CONVERT(date, TRAN_DATE) 
	BETWEEN 
	DATEADD(MONTH,-3,(SELECT MAX(CONVERT(DATE,TRAN_DATE)) FROM Transactions)) AND (SELECT MAX(CONVERT(DATE,TRAN_DATE)) FROM Transactions)
GROUP BY
P.PROD_CAT
ORDER BY
TOTAL_RETURNS DESC



--Q13. Which store-type sells the maximum products; by value of sales amount and by quantity sold?
SELECT TOP 1
STORE_TYPE, Total_Sales, Total_Quantity
FROM 
(
    SELECT
    STORE_TYPE,
    SUM(TOTAL_AMT) AS Total_Sales,
    SUM(QTY) AS Total_Quantity,
    ROW_NUMBER() OVER (ORDER BY SUM(TOTAL_AMT) DESC, SUM(QTY) DESC) AS RowNum
    FROM
    Transactions
    GROUP BY
    STORE_TYPE ) AS Ranking_Calc
WHERE
RowNum = 1;



--Q14. What are the categories for which average revenue is above the overall average?
SELECT
P.PROD_CAT,
AVG(T.TOTAL_AMT) AS AVG_REVENUE
FROM
Transactions AS T
INNER JOIN prod_cat_info AS P ON T.PROD_CAT_CODE = P.PROD_CAT_CODE AND T.PROD_SUBCAT_CODE = P.PROD_SUB_CAT_CODE
GROUP BY
P.PROD_CAT
HAVING
AVG(T.TOTAL_AMT) > (SELECT AVG(TOTAL_AMT) AS TOTAL_AVG FROM Transactions);



--Q15. Find the average and total revenue by each subcategory for the categories which are among top 5 categories 
-------in terms of quantity sold.
SELECT 
PROD_CAT, PROD_SUBCAT, AVG(TOTAL_AMT) AS AVERAGE_REV, SUM(TOTAL_AMT) AS TOTAL_REV
FROM
Transactions AS T
INNER JOIN prod_cat_info AS P ON T.PROD_CAT_CODE = P.PROD_CAT_CODE AND T.PROD_SUBCAT_CODE = P.PROD_SUB_CAT_CODE
WHERE
PROD_CAT IN
(
     SELECT TOP 5 
     PROD_CAT
	 FROM
	 Transactions AS T
     INNER JOIN prod_cat_info AS P ON T.PROD_CAT_CODE = P.PROD_CAT_CODE AND T.PROD_SUBCAT_CODE = P.PROD_SUB_CAT_CODE
	 GROUP BY PROD_CAT
	 ORDER BY SUM(QTY) DESC
)
GROUP BY
PROD_CAT, PROD_SUBCAT



/*************************************************************************************************************************************/
/*************************************************************************************************************************************/